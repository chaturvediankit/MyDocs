package com.spring.assignment.addNum.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.assignment.addNum.service.IntegerSum;

@Controller
@RequestMapping("/project/add-api")
public class AssignmentController {
	
	@Autowired
	private IntegerSum integerSum;
	
	private static final Logger log = LoggerFactory.getLogger(AssignmentController.class);

	@GetMapping("/addNum/{num1}/{num2}")
	public @ResponseBody int addNum(@PathVariable int num1, @PathVariable int num2) {
		
		int sum = integerSum.getSumNumber(num1, num2);
		log.info("Sum of numbers {} and {}",num1,num2 +" is "+sum);
		return sum;
		
	}
}
