package com.spring.assignment.addNum.service;

import org.springframework.stereotype.Service;

@Service
public class IntegerSum {

	public int getSumNumber(int num1, int num2) {		
		return num1+num2;
	}
	
	

}
